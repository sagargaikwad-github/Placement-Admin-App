package com.example.placementadminapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.placementadminapp.Guidence.DeleteGuide;
import com.example.placementadminapp.company.DeleteCompany;
import com.example.placementadminapp.ebook.DeleteEBookActivity;
import com.example.placementadminapp.notice.deleteNotice;

public class DeleteMain extends AppCompatActivity implements View.OnClickListener {
    Button btn1,btn2,btn3,btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_main);
        getSupportActionBar();
        setTitle("Delete Records");

        btn1 = findViewById(R.id.deleteN1Btn);
        btn1.setOnClickListener(this);

        btn2= findViewById(R.id.deleteN2Btn);
        btn2.setOnClickListener(this);

        btn3= findViewById(R.id.deleteN3Btn);
        btn3.setOnClickListener(this);

        btn4= findViewById(R.id.deleteN4btn);
        btn4.setOnClickListener(this);


    }
        @Override
        public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.deleteN1Btn:
                Intent intent=new Intent(DeleteMain.this, deleteNotice.class);
                startActivity(intent);
                break;

            case R.id.deleteN2Btn:
                Intent intent1=new Intent(DeleteMain.this, DeleteCompany.class);
                startActivity(intent1);
                break;

            case R.id.deleteN3Btn:
                Intent intent2=new Intent(DeleteMain.this, DeleteEBookActivity.class);
                startActivity(intent2);
                break;

            case R.id.deleteN4btn:
                Intent intent3=new Intent(DeleteMain.this, DeleteGuide.class);
                startActivity(intent3);
                break;



        }

    }
}