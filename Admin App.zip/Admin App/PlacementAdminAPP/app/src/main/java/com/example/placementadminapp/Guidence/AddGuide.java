package com.example.placementadminapp.Guidence;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.placementadminapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class AddGuide extends AppCompatActivity {

    private EditText addGName,addGPost,addGEmail,addGExperience,addGLang;

    private Button add;
    private String Guidence;
    private String name,email,post,downloadUrl="",key,experience,language;
    private ProgressDialog pd;
    private StorageReference storageReference;
    private DatabaseReference reference,dbRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_guidence);
        this.setTitle("Add Guidence");
        getSupportActionBar();

        addGName=findViewById(R.id.addGname);
        addGEmail=findViewById(R.id.addGEmail);
        addGExperience=findViewById(R.id.addGExperience);
        addGPost=findViewById(R.id.addGPost);
        addGLang=findViewById(R.id.addGLang);
        add=findViewById(R.id.add);

        pd=new ProgressDialog(this);



        //reference= FirebaseDatabase.getInstance().getReference().child("Guidence");
        storageReference= FirebaseStorage.getInstance().getReference();





        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidation();
            }
        });
    }

    private void insertData()
    {
        dbRef=FirebaseDatabase.getInstance().getReference().child("Guidence");
        final String uniqueKey = dbRef.push().getKey();

        GuidenceData guidenceData=new GuidenceData(name,email,post,uniqueKey,experience,language);
        dbRef.child(uniqueKey).setValue(guidenceData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void avoid) {
                pd.dismiss();
                Toast.makeText(AddGuide.this,"Guide Added", Toast.LENGTH_SHORT).show();

                addGName.setText("");
                addGEmail.setText("");
                addGPost.setText("");
                addGExperience.setText("");
                addGLang.setText("");

                addGName.requestFocus();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                pd.dismiss();
                Toast.makeText(AddGuide.this,"Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkValidation() {
        name=addGName.getText().toString();
        email=addGEmail.getText().toString();
        post=addGPost.getText().toString();
        experience=addGExperience.getText().toString();
        language=addGLang.getText().toString();


        if(name.isEmpty())
        {
            addGName.setError("Empty");
            addGName.requestFocus();
        }else if(email.isEmpty()) {
            addGEmail.setError("Empty");
            addGEmail.requestFocus();
        }
        else if(post.isEmpty())
        {
        addGPost.setError("Empty");
        addGPost.requestFocus();
        }
        else
        {
            pd.setMessage("Uploading...");
            pd.show();
            insertData();

        }



    }
}