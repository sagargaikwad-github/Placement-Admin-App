package com.example.placementadminapp.Guidence;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.placementadminapp.R;
import com.example.placementadminapp.company.CompanyAdapter;
import com.example.placementadminapp.company.CompanyData;
import com.example.placementadminapp.company.DeleteCompany;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DeleteGuide  extends AppCompatActivity {

    private RecyclerView deleteGuideRecycler1;
    private ProgressBar progressBar1;
    private ArrayList<GuidenceData> list;
    private GuideAdapter adapter;


    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_guide);
        getSupportActionBar();
        deleteGuideRecycler1=findViewById(R.id.deleteGuideRecycler);
        progressBar1=findViewById(R.id.progressBar1);

        // reference= FirebaseDatabase.getInstance().getReference().child("Job Details");
        reference= FirebaseDatabase.getInstance().getReference().child("Guidence");

        deleteGuideRecycler1.setLayoutManager(new LinearLayoutManager(this));
        deleteGuideRecycler1.setHasFixedSize(true);


        getGuide();
    }

    private void getGuide() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                list=new ArrayList<>();
                for (DataSnapshot snapshot: datasnapshot.getChildren())
                {
                    GuidenceData data=snapshot.getValue(GuidenceData.class);
                    list.add(0,data);
                }
                adapter=new GuideAdapter(DeleteGuide.this,list);
                adapter.notifyDataSetChanged();
                progressBar1.setVisibility(View.GONE);
                deleteGuideRecycler1.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                progressBar1.setVisibility(View.GONE);

                Toast.makeText(DeleteGuide.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });

    }
}