package com.example.placementadminapp.Guidence;

public class GuidenceData {

    private String name,email,post,key,experience,language;

    public GuidenceData() {
    }

    public GuidenceData(String name, String email, String post, String key, String experience, String language) {
        this.name = name;
        this.email = email;
        this.post = post;
        this.key = key;
        this.experience = experience;
        this.language = language;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
