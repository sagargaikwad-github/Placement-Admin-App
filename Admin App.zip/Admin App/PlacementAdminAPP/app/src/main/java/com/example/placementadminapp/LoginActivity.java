package com.example.placementadminapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private TextView login_btn,txt_show;
    private EditText user_email,user_pass;

    private String email,pass;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;


    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setMessage("Do you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        LoginActivity.super.onBackPressed();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        sharedPreferences = this.getSharedPreferences("login",MODE_PRIVATE);
        editor=sharedPreferences.edit();

        if(sharedPreferences.getString("isLogin","false").equals("yes"))
        {
            openDash();

        }


        user_email=findViewById(R.id.user_email);
        user_pass=findViewById(R.id.user_pass);
        txt_show=findViewById(R.id.txt_Show);
        login_btn=findViewById(R.id.login_btn);

        txt_show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user_pass.getInputType()==144)
                {
                    user_pass.setInputType(129);
                    txt_show.setText("Hide");
                }
                else{
                    user_pass.setInputType(144);
                    txt_show.setText("Show");
                }
                user_pass.setSelection(user_pass.getText().length());
            }

        });

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ValidateData();
            }
        });

    }

    private void ValidateData() {
        email = user_email.getText().toString();
        pass = user_pass.getText().toString();

        if(email.isEmpty()){
            user_email.setError("Required");
            user_email.requestFocus();
        }
        else if(pass.isEmpty())
        {
            user_pass.setError("Required");
            user_pass.requestFocus();
        }
        else if(email.equals("myadmin@gmail.com") && pass.equals("12345"))
        {
            editor.putString("isLogin","yes");
            editor.commit();
            openDash();

        }else{
            Toast.makeText(this, "Please check email and password again", Toast.LENGTH_LONG).show();
        }

    }

    private void openDash() {
        startActivity(new Intent(LoginActivity.this,MainActivity.class));
        finish();
    }



}
