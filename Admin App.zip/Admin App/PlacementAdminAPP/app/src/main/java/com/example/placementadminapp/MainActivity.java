package com.example.placementadminapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.placementadminapp.Guidence.AddGuide;
import com.example.placementadminapp.company.AddCompany;
import com.example.placementadminapp.ebook.UploadEbook;
import com.example.placementadminapp.faculty.UpdateFaculty;
import com.example.placementadminapp.notice.UploadNotice;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
      CardView uploadNotice,addCompany,addEbook,faculty,deleteNotice,addGuidence;
      private SharedPreferences sharedPreferences;
      private SharedPreferences.Editor editor;
    private MainActivity toggle;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       //FirebaseMessaging.getInstance().subscribeToTopic("all");

        sharedPreferences = this.getSharedPreferences("login",MODE_PRIVATE);
        editor=sharedPreferences.edit();

        if(sharedPreferences.getString("isLogin","false").equals("false"))
        {
            openLogin();
        }



        uploadNotice=findViewById(R.id.addNotice);
        uploadNotice.setOnClickListener(this);

        addCompany=findViewById(R.id.addCompany);
        addCompany.setOnClickListener(this);

        addEbook=findViewById(R.id.addEbook);
        addEbook.setOnClickListener(this);

        faculty=findViewById(R.id.faculty);
        faculty.setOnClickListener(this);

        deleteNotice=findViewById(R.id.deleteNotice);
        deleteNotice.setOnClickListener(this);

        addGuidence=findViewById(R.id.addGuidence);
        addGuidence.setOnClickListener(this);


        //Upload Notice:
//        View cardViewNotice = findViewById(R.id.addNotice);
//        cardViewNotice.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(MainActivity.this, UploadNotice.class);
//                startActivity(i);
//            }
//        });


    }

    private void openLogin() {
        startActivity(new Intent(MainActivity.this,LoginActivity.class));
        finish();
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        if(toggle.onOptionsItemSelected(item))
//            return true;
        switch (item.getItemId())
        {
            case R.id.option_logout:
                editor.putString("isLogin","false");
                editor.commit();
                openLogin();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.addNotice:
                Intent intent=new Intent(MainActivity.this, UploadNotice.class);
                startActivity(intent);

                break;
            case R.id.addCompany:
                Intent intent1=new Intent(MainActivity.this, AddCompany.class);
                startActivity(intent1);
                break;
            case R.id.addEbook:
                Intent intent2=new Intent(MainActivity.this, UploadEbook.class);
                startActivity(intent2);
                break;

            case R.id.faculty:
                Intent intent3=new Intent(MainActivity.this, UpdateFaculty.class);
                startActivity(intent3);
                break;

            case R.id.deleteNotice:
                Intent intent4=new Intent(MainActivity.this, DeleteMain.class);
                startActivity(intent4);
                break;

            case R.id.addGuidence:
                Intent intent5=new Intent(MainActivity.this, AddGuide.class);
                startActivity(intent5);
                break;



        }


    }



    public AlertDialog.Builder buildDialog(Context context) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Error");
        builder.setMessage("No Internet connection");
        builder.setCancelable(false);
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                builder.setCancelable(true);
            }
        });
        return builder;
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setMessage("Do you want to Exit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       MainActivity.super.onBackPressed();
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();


    }
}
