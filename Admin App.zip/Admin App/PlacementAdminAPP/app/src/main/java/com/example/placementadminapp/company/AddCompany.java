package com.example.placementadminapp.company;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.placementadminapp.FcmNotificationsSender;
import com.example.placementadminapp.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Calendar;


public class AddCompany extends AppCompatActivity {
    private EditText name,profile,description,link,enddate;
    private Button save,notification;
    private String CompanyName, Profile, Description,Link,Enddate;
    private StorageReference storageReference;
    private DatabaseReference reference,dbRef;
    private ProgressDialog pd;
    private Object Date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_company);
        setTitle("Add Company");
        getSupportActionBar();

      //  FirebaseMessaging.getInstance().subscribeToTopic("all");

        name = findViewById(R.id.addtitle);
        profile = findViewById(R.id.jobtitle);
        description = findViewById(R.id.companyDescription);
        link = findViewById(R.id.companyUrl);
        enddate = findViewById(R.id.endDate);
        save = findViewById(R.id.saveBtn);
        //notification = findViewById(R.id.notification);

        pd = new ProgressDialog(this);
        reference = FirebaseDatabase.getInstance().getReference().child("Job Details");
        storageReference = FirebaseStorage.getInstance().getReference();

//
//        String t1 = "New Drive";
//        String t2 = "Tap to view";

//        save.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                HashMap<String,Object>map=new HashMap<>();
//                map.put("name",name.getText().toString());
//                map.put("profile",profile.getText().toString());
//                map.put("description",description.getText().toString());
//                map.put("link",link.getText().toString());
//                map.put("enddate",enddate.getText().toString());
//
//                FirebaseDatabase.getInstance().getReference().child("Job Details").push()
//                        .setValue(map)
//                        .addOnCompleteListener(new OnCompleteListener<Void>() {
//                            @Override
//                            public void onComplete(@NonNull Task<Void> task) {
//                                Log.i("fgg", "onComplete: ");
//                                Toast.makeText(AddCompany.this,"Job Added", Toast.LENGTH_SHORT).show();
//                            }
//                        }).addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        Log.i("ghh", "onFailure: "+e.toString());
//                        Toast.makeText(AddCompany.this,"Something went wrong", Toast.LENGTH_SHORT).show();
//                    }
//                });
//
//
//
//            }
//        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkValidation();
            }
        });

//        notification.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });


    }

    private void checkValidation() {
        CompanyName=name.getText().toString();
        Profile=profile.getText().toString();
        Description=description.getText().toString();
        Link=link.getText().toString();
        Enddate=enddate.getText().toString();

        if(CompanyName.isEmpty())
        {
            name.setError("Error");
            name.requestFocus();
        }else if(Profile.isEmpty())
        {
            profile.setError("Error");
            profile.requestFocus();
        }else if(Description.isEmpty())
        {
            description.setError("Error");
            description.requestFocus();
        }
        else if(Link.isEmpty())
        {
            link.setError("Error");
            link.requestFocus();
        }else if(Enddate.isEmpty())
        {
            enddate.setError("Error");
            enddate.requestFocus();
        }else
        {
            insertData();
            FcmNotificationsSender notificationsSender = new FcmNotificationsSender("/topics/all", "New Drive",
                    "Tap to View", getApplicationContext(), AddCompany.this);
            notificationsSender.SendNotifications();

        }

    }

    private void insertData() {

        dbRef=reference.child("");
        final String uniqueKey=dbRef.push().getKey();

        Calendar calForDate=Calendar.getInstance();
        SimpleDateFormat currentDate= new SimpleDateFormat("dd-MM-yy");
        String date=currentDate.format(calForDate.getTime());

        Calendar calForTime=Calendar.getInstance();
        SimpleDateFormat currentTime=new SimpleDateFormat("hh:mm a");
        String time=currentTime.format(calForTime.getTime());


        CompanyData companyData=new CompanyData(CompanyName, Profile, Description,Link,date,time,Enddate,uniqueKey);
        dbRef.child(uniqueKey).setValue(companyData).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void avoid) {
                Toast.makeText(AddCompany.this,"Company Added",Toast.LENGTH_SHORT).show();
                pd.dismiss();

                 name.setText("");
                profile.setText("");
                description.setText("");
                link.setText("");
                 enddate.setText("");

                name.requestFocus();


            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(AddCompany.this, "Something went wrong", Toast.LENGTH_SHORT).show();

            }
        });

    }

//    private void sendNotification(PushNotification notification) {
//        ApiUtilities.getClient().sendNotification(notification).enqueue(new Callback<PushNotification>() {
//
//            @Override
//            public void onResponse(Call<PushNotification> call, Response<PushNotification> response) {
//
//
//                if (response.isSuccessful())
////                    Toast.makeText(AddCompany.this, response.toString(), Toast.LENGTH_SHORT).show();
//                    Toast.makeText(AddCompany.this, "Sucess", Toast.LENGTH_SHORT).show();
//                else
//                    Toast.makeText(AddCompany.this, "error", Toast.LENGTH_SHORT).show();
//
//            }
//
//
//            @Override
//            public void onFailure(Call<PushNotification> call, Throwable t) {
//                Toast.makeText(AddCompany.this, t.getMessage(), Toast.LENGTH_SHORT).show();
//
//            }
//        });
//    }
}