package com.example.placementadminapp.company;

public class CompanyData {

    private String CompanyName;


    private String Profile;
    private String Description;
    private String Link;
    private String Date;
    private String Time;
    private String Enddate;
    private String key;

    public CompanyData() {
    }

    public CompanyData(String companyName, String profile, String description, String link, String date, String time, String enddate, String key) {
        CompanyName = companyName;
        Profile = profile;
        Description = description;
        Link = link;
        Date = date;
        Time = time;
        Enddate = enddate;
        this.key = key;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }

    public String getProfile() {
        return Profile;
    }

    public void setProfile(String profile) {
        Profile = profile;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getLink() {
        return Link;
    }

    public void setLink(String link) {
        Link = link;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getEnddate() {
        return Enddate;
    }

    public void setEnddate(String enddate) {
        Enddate = enddate;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
