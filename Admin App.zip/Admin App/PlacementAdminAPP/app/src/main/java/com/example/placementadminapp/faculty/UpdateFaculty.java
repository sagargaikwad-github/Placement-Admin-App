package com.example.placementadminapp.faculty;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.placementadminapp.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UpdateFaculty extends AppCompatActivity {
    FloatingActionButton fab;
    private RecyclerView bbaDepartment,bcsDepartment,bcaDepartment,mbaDepartment,mcsDepartment,mcaDepartment;
    private LinearLayout bbanodata,bcsnodata,bcanodata,mbanodata,mcsnodata,mcanodata;
    private List<TeacherData> list1,list2,list3,list4,list5,list6;
    private TeacherAdapter adapter;

    private DatabaseReference reference,dbRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_faculty);
        this.setTitle("Placement Co-ordinator");
        getSupportActionBar();

        bbaDepartment=findViewById(R.id.bbaDepartment);
        bcsDepartment=findViewById(R.id.bcsDepartment);
        bcaDepartment=findViewById(R.id.bcaDepartment);
        mbaDepartment=findViewById(R.id.mbaDepartment);
        mcsDepartment=findViewById(R.id.mcsDepartment);
        mcaDepartment=findViewById(R.id.mcaDepartment);

        bbanodata=findViewById(R.id.bbanoData);
        bcsnodata=findViewById(R.id.bcsnoData);
        bcanodata=findViewById(R.id.bcanoData);
        mbanodata=findViewById(R.id.mbanoData);
        mcsnodata=findViewById(R.id.mcsnoData);
        mcanodata=findViewById(R.id.mcanoData);

        reference = FirebaseDatabase.getInstance().getReference().child("teacher");

        bbaDepartment();
        bcsDepartment();
        bcaDepartment();

        mbaDepartment();
        mcsDepartment();
        mcaDepartment();








        fab=findViewById(R.id.fab);

         fab.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 startActivity(new Intent(UpdateFaculty.this, AddTeacher.class));
             }
         });
    }

    private void bbaDepartment() {
        dbRef=reference.child("BBA");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list1=new ArrayList<>();
                if(!dataSnapshot.exists())
                {
                    bbanodata.setVisibility(View.VISIBLE);
                    bbaDepartment.setVisibility(View.GONE);
                }
                else
                {
                    bbanodata.setVisibility(View.GONE);
                    bbaDepartment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot: dataSnapshot.getChildren())
                    {
                        TeacherData data=snapshot.getValue(TeacherData.class);
                        list1.add(data);
                    }
                    bbaDepartment.setHasFixedSize(true);
                    bbaDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter=new TeacherAdapter(list1,UpdateFaculty.this,"BBA");
                    bbaDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void bcsDepartment() {
        dbRef=reference.child("BCS");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list2=new ArrayList<>();
                if(!dataSnapshot.exists())
                {
                    bcsnodata.setVisibility(View.VISIBLE);
                    bcsDepartment.setVisibility(View.GONE);
                }
                else
                {
                    bcsnodata.setVisibility(View.GONE);
                    bcsDepartment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot: dataSnapshot.getChildren())
                    {
                        TeacherData data=snapshot.getValue(TeacherData.class);
                        list2.add(data);
                    }
                    bcsDepartment.setHasFixedSize(true);
                    bcsDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter=new TeacherAdapter(list2,UpdateFaculty.this,"BCS");
                    bcsDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void bcaDepartment() {
        dbRef=reference.child("BCA");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list3=new ArrayList<>();
                if(!dataSnapshot.exists())
                {
                    bcanodata.setVisibility(View.VISIBLE);
                    bcaDepartment.setVisibility(View.GONE);
                }
                else
                {
                    bcanodata.setVisibility(View.GONE);
                    bcaDepartment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot: dataSnapshot.getChildren())
                    {
                        TeacherData data=snapshot.getValue(TeacherData.class);
                        list3.add(data);
                    }
                    bcaDepartment.setHasFixedSize(true);
                    bcaDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter=new TeacherAdapter(list3,UpdateFaculty.this,"BCA");
                    bcaDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void mbaDepartment() {
        dbRef=reference.child("MBA");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list4=new ArrayList<>();
                if(!dataSnapshot.exists())
                {
                    mbanodata.setVisibility(View.VISIBLE);
                    mbaDepartment.setVisibility(View.GONE);
                }
                else
                {
                    mbanodata.setVisibility(View.GONE);
                    mbaDepartment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot: dataSnapshot.getChildren())
                    {
                        TeacherData data=snapshot.getValue(TeacherData.class);
                        list4.add(data);
                    }
                    mbaDepartment.setHasFixedSize(true);
                    mbaDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter=new TeacherAdapter(list4,UpdateFaculty.this,"MBA");
                    mbaDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void mcsDepartment() {
        dbRef=reference.child("MCS");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list5=new ArrayList<>();
                if(!dataSnapshot.exists())
                {
                    mcsnodata.setVisibility(View.VISIBLE);
                    mcsDepartment.setVisibility(View.GONE);
                }
                else
                {
                    mcsnodata.setVisibility(View.GONE);
                    mcsDepartment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot: dataSnapshot.getChildren())
                    {
                        TeacherData data=snapshot.getValue(TeacherData.class);
                        list5.add(data);
                    }
                    mcsDepartment.setHasFixedSize(true);
                    mcsDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter=new TeacherAdapter(list5,UpdateFaculty.this,"MCS");
                    mcsDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
    private void mcaDepartment() {
        dbRef=reference.child("MCA");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                list6=new ArrayList<>();
                if(!dataSnapshot.exists())
                {
                    mcanodata.setVisibility(View.VISIBLE);
                    mcaDepartment.setVisibility(View.GONE);
                }
                else
                {
                    mcanodata.setVisibility(View.GONE);
                    mcaDepartment.setVisibility(View.VISIBLE);
                    for (DataSnapshot snapshot: dataSnapshot.getChildren())
                    {
                        TeacherData data=snapshot.getValue(TeacherData.class);
                        list6.add(data);
                    }
                    mcaDepartment.setHasFixedSize(true);
                    mcaDepartment.setLayoutManager(new LinearLayoutManager(UpdateFaculty.this));
                    adapter=new TeacherAdapter(list6,UpdateFaculty.this,"MCA");
                    mcaDepartment.setAdapter(adapter);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(UpdateFaculty.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }





}