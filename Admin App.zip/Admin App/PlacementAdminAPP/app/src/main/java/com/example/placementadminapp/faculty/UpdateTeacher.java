package com.example.placementadminapp.faculty;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.placementadminapp.R;
import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;

public class UpdateTeacher extends AppCompatActivity {
    private EditText updateTeacherName,updateTeacherEmail,updateTeacherPost;
    private Button updateTeacherBtn,deleteTeacherBtn;
    private StorageReference storageReference;
    private DatabaseReference reference;
    private String category,uniqueKey;

    private String name,email,post;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_teacher);
        this.setTitle("Update Teacher");
        getSupportActionBar();

        name=getIntent().getStringExtra("name");
       // post=getIntent().getStringExtra("post");
        email=getIntent().getStringExtra("email");


         uniqueKey=getIntent().getStringExtra("key");
         category=getIntent().getStringExtra("category");

        updateTeacherName=findViewById(R.id.updateTeacherName);
       // updateTeacherPost=findViewById(R.id.updateTeacherPost);
        updateTeacherEmail=findViewById(R.id.updateTeacherEmail);

        updateTeacherBtn=findViewById(R.id.updateTeacherBtn);
        deleteTeacherBtn=findViewById(R.id.deleteTeacherBtn);

        reference= FirebaseDatabase.getInstance().getReference().child("teacher");
        storageReference= FirebaseStorage.getInstance().getReference();



        updateTeacherName.setText(name);
      //  updateTeacherPost.setText(post);
        updateTeacherEmail.setText(email);


        updateTeacherBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name=updateTeacherName.getText().toString();
               // post=updateTeacherPost.getText().toString();
                email=updateTeacherEmail.getText().toString();
                checkValidation();
            }
        });

        deleteTeacherBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData();
            }
        });

    }

    private void checkValidation() {

        if(name.isEmpty())
        {
            updateTeacherName.setError("Empty");
            updateTeacherName.requestFocus();
//        }else if(post.isEmpty())
//        {
//            updateTeacherPost.setError("Empty");
//            updateTeacherPost.requestFocus();
        }else if(email.isEmpty())
        {
            updateTeacherEmail.setError("Empty");
            updateTeacherEmail.requestFocus();
        }
        else
        {
            updateData();
        }

    }

    private void updateData() {
        HashMap hp=new HashMap();
        hp.put("name",name);
       // hp.put("post",post);
        hp.put("email",email);

        reference.child(category).child(uniqueKey).updateChildren(hp).addOnSuccessListener(new OnSuccessListener() {
            @Override
            public void onSuccess(Object o) {
                Toast.makeText(UpdateTeacher.this, "Teacher Updated", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(UpdateTeacher.this,UpdateFaculty.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UpdateTeacher.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void deleteData() {
        reference.child(category).child(uniqueKey).removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        Toast.makeText(UpdateTeacher.this, "Teacher Deleted", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(UpdateTeacher.this,UpdateFaculty.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(UpdateTeacher.this, "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        });


    }
}