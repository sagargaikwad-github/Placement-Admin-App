package com.example.placementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class FullImageView extends AppCompatActivity {

    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_image_view);
        this.setTitle("Full Notice");

        image=findViewById(R.id.image);

        String imageview=getIntent().getStringExtra("image");


        Glide.with(this).load(imageview).into(image);
    }
}