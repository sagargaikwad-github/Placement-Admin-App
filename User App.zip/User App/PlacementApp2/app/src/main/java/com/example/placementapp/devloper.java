package com.example.placementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class devloper extends AppCompatActivity {
    private TextView home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_devloper);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Devlopers");

        home=findViewById(R.id.home);

//        home.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent(devloper.this,MainActivity.class);
//                startActivity(intent);
//                finishAffinity();
//            }
//        });
    }
}