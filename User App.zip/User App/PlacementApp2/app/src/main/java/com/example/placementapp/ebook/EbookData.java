package com.example.placementapp.ebook;

public class EbookData {
    private String pdfTitle,pdfUrl,uniquekey;

    public EbookData() {
    }

    public EbookData(String pdfTitle, String pdfUrl, String uniquekey) {
        this.pdfTitle = pdfTitle;
        this.pdfUrl = pdfUrl;
        this.uniquekey = uniquekey;
    }

    public String getPdfTitle() {
        return pdfTitle;
    }

    public void setPdfTitle(String pdfTitle) {
        this.pdfTitle = pdfTitle;
    }

    public String getPdfUrl() {
        return pdfUrl;
    }

    public void setPdfUrl(String pdfUrl) {
        this.pdfUrl = pdfUrl;
    }

    public String getUniquekey() {
        return uniquekey;
    }

    public void setUniquekey(String uniquekey) {
        this.uniquekey = uniquekey;
    }
}
