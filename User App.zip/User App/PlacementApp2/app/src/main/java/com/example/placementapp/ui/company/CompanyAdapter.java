package com.example.placementapp.ui.company;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.placementapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.util.ArrayList;
import java.util.Locale;

public class CompanyAdapter extends RecyclerView.Adapter<CompanyAdapter.CompanyViewAdapter>  {
    private Context context;
    private ArrayList<CompanyData> list;

    public CompanyAdapter(Context context, ArrayList<CompanyData> list) {
        this.context = context;
        this.list = list;

    }

    @NonNull
    @Override
    public CompanyViewAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.newsfeed_company_layout, parent, false);
        return new CompanyViewAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CompanyViewAdapter holder, @SuppressLint("RecyclerView") int position) {
        CompanyData currentItem = list.get(position);


        holder.CompanyName.setText(currentItem.getCompanyName());
        holder.Profile.setText(currentItem.getProfile());
        holder.Description.setText(currentItem.getDescription());
        holder.Link.setText(currentItem.getLink());
        holder.Date.setText(currentItem.getDate());
        holder.End.setText(currentItem.getEnddate());
        holder.Time.setText(currentItem.getTime());


    }


    @Override
    public int getItemCount() {
        return list.size();
//        if(list == null)
//             return 0;
//          return list.size();
    }




    public class CompanyViewAdapter extends RecyclerView.ViewHolder {

        private TextView CompanyName, Profile, Description, Link, Date, End, Time;

        public CompanyViewAdapter(@NonNull View itemView) {
            super(itemView);

            CompanyName = itemView.findViewById(R.id.CompanyName);
            Profile = itemView.findViewById(R.id.profile);
            Description = itemView.findViewById(R.id.companyDesc);
            Link = itemView.findViewById(R.id.link);
            Date = itemView.findViewById(R.id.date);
            End = itemView.findViewById(R.id.end);
            Time = itemView.findViewById(R.id.time);

//            deleteCompanyName=itemView.findViewById(R.id.deleteCompanyName);
//            deleteCompanyProfile=itemView.findViewById(R.id.deleteCompanyProfile);
//            deleteCompanyDescription=itemView.findViewById(R.id.deleteCompanyDescription);
//            deleteCompanyLink=itemView.findViewById(R.id.deleteCompanyLink);
//            deleteCompanyDate=itemView.findViewById(R.id.deleteCompanyDate);
//            deleteDate=itemView.findViewById(R.id.deleteDate);
//            deleteTime=itemView.findViewById(R.id.deleteTime);


        }
    }
}
