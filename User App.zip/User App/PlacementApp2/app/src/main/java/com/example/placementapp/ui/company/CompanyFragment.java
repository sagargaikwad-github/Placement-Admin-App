package com.example.placementapp.ui.company;

import android.icu.text.Transliterator;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.placementapp.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class CompanyFragment extends Fragment {
    private RecyclerView deleteCompanyRecycler1;
    private ProgressBar progressBar1;
    private ArrayList<CompanyData> list;
    private CompanyAdapter adapter;
    private DatabaseReference reference;
    private TextView link;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Apply For Drive");
        View view=inflater.inflate(R.layout.fragment_company, container, false);

        deleteCompanyRecycler1=view.findViewById(R.id.deleteCompanyRecycler1);
        progressBar1=view.findViewById(R.id.progressBar1);

        link=view.findViewById(R.id.link);


        reference= FirebaseDatabase.getInstance().getReference().child("Job Details");

        deleteCompanyRecycler1.setLayoutManager(new LinearLayoutManager(getContext()));
        deleteCompanyRecycler1.setHasFixedSize(true);


        getCompany();
        return view;

    }


    private void getCompany() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                list=new ArrayList<>();
                for (DataSnapshot snapshot: datasnapshot.getChildren())
                {
                    CompanyData data=snapshot.getValue(CompanyData.class);
                    list.add(0,data);
                }
                adapter=new CompanyAdapter(getContext(),list);
                adapter.notifyDataSetChanged();
                progressBar1.setVisibility(View.GONE);
                deleteCompanyRecycler1.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                progressBar1.setVisibility(View.GONE);

                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }


}