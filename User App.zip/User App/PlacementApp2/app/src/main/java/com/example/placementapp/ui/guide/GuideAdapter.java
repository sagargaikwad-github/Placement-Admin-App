package com.example.placementapp.ui.guide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.placementapp.R;

import java.util.ArrayList;

public class GuideAdapter extends RecyclerView.Adapter<GuideAdapter.GuideViewAdapter> {
    private Context context;
    private ArrayList<GuidenceData> list;

    public GuideAdapter (Context context, ArrayList<GuidenceData> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public GuideViewAdapter onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.guide_item_layout,parent,false);
        return new GuideViewAdapter(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GuideViewAdapter holder, @SuppressLint("RecyclerView") int position) {
        GuidenceData currentItem = list.get(position);


        holder.guideName.setText(currentItem.getName());
        holder.guideEmail.setText(currentItem.getEmail());
        holder.guidePost.setText(currentItem.getPost());
        holder.guideExperience.setText(currentItem.getExperience());
        holder.guideExpert.setText(currentItem.getLanguage());


    }


    @Override
    public int getItemCount() {
        return list.size();
//        if(list == null)
//             return 0;
//          return list.size();
    }

    public class GuideViewAdapter extends RecyclerView.ViewHolder{

        private TextView guideName,guideEmail,guidePost,guideExperience,guideExpert;
        public GuideViewAdapter(@NonNull View itemView) {
            super(itemView);

            guideName=itemView.findViewById(R.id.guideName);
            guideEmail=itemView.findViewById(R.id.guideEmail);
            guidePost=itemView.findViewById(R.id.guidePost);
            guideExperience=itemView.findViewById(R.id.guideExperience);
            guideExpert=itemView.findViewById(R.id.guideExpert);


        }
    }
}

