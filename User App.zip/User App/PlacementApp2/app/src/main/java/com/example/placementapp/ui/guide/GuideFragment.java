package com.example.placementapp.ui.guide;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.placementapp.R;
import com.example.placementapp.ui.company.CompanyAdapter;
import com.example.placementapp.ui.company.CompanyData;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class GuideFragment extends Fragment {
    private RecyclerView guideRecycler;
    private DatabaseReference reference;
    private ProgressBar progressBar;
    private ArrayList<GuidenceData> list;
    private GuideAdapter adapter;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Guide");
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_guide, container, false);

        guideRecycler=view.findViewById(R.id.guideRecycler);
        progressBar=view.findViewById(R.id.progressBar);

        //link=view.findViewById(R.id.link);


        // reference= FirebaseDatabase.getInstance().getReference().child("Job Details");
        reference= FirebaseDatabase.getInstance().getReference().child("Guidence");

        guideRecycler.setLayoutManager(new LinearLayoutManager(getContext()));
        guideRecycler.setHasFixedSize(true);


        getCompany();
        return view;

    }


    private void getCompany() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot datasnapshot) {
                list=new ArrayList<>();
                for (DataSnapshot snapshot: datasnapshot.getChildren())
                {
                    GuidenceData data=snapshot.getValue(GuidenceData.class);
                    list.add(0,data);
                }
                adapter=new GuideAdapter(getContext(),list);
                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);
                guideRecycler.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                progressBar.setVisibility(View.GONE);

                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }


}