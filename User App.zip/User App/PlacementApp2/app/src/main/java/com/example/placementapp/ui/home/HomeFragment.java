package com.example.placementapp.ui.home;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.placementapp.R;
import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderLayout;

public class HomeFragment extends Fragment {
    private SliderLayout sliderLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Home");
        View view= inflater.inflate(R.layout.fragment_home, container, false);

        sliderLayout=view.findViewById(R.id.slider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.FILL);
        sliderLayout.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        sliderLayout.setScrollTimeInSec(2);



        setSliderImages();

        return view;
    }

    private void setSliderImages() {
        for(int i=0;i<5;i++)
        {
            DefaultSliderView sliderView=new DefaultSliderView(getContext());

            switch (i)
            {
                case 0:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/placement-app-d714f.appspot.com/o/sinhgadsci.jpg?alt=media&token=ac9ba673-9090-4f0c-937b-2f54cb70374d");
                    break;
                case 1 :
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/placement-app-d714f.appspot.com/o/loveandroid.jfif?alt=media&token=55ee7395-e69e-4726-bb15-a350a83ea5b5");
                    break;
                case 2:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/placement-app-d714f.appspot.com/o/web%20dev.png?alt=media&token=711048a9-4187-4473-983e-8c4b4e4d7b6a");
                    break;
                case 3:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/placement-app-d714f.appspot.com/o/ml.jfif?alt=media&token=b4a9d262-ba20-48b0-95af-e9841fd5d8e3");
                    break;
                case 4:
                    sliderView.setImageUrl("https://firebasestorage.googleapis.com/v0/b/placement-app-d714f.appspot.com/o/sinhgadmain.jfif?alt=media&token=c46b7b91-3766-4c98-b02b-c46623c0406c");
                    break;
            }
            sliderView.setImageScaleType(ImageView.ScaleType.FIT_XY);

            sliderLayout.addSliderView(sliderView);
        }
    }
}