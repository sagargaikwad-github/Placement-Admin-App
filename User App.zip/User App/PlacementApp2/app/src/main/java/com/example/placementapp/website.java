package com.example.placementapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class website extends AppCompatActivity {
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_website);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Website");

        webView=findViewById(R.id.web);
        webView.loadUrl("https://www.indiabix.com/");
        webView.getSettings().setJavaScriptEnabled(true);
        //webView.getSettings().supportZoom();
        webView.getSettings().setBuiltInZoomControls(true);
//        webView.loadUrl("https://www.flipkart.com/");



    }
}